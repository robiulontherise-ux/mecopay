=== MecoPay Smart Dual-Gateway for WooCommerce ===
Contributors: mecopay
Tags: mecopay, bkash, nagad, rocket, payment gateway, woocommerce, cod
Requires at least: 5.4
Tested up to: 6.7
Requires PHP: 7.4
Requires Plugins: woocommerce
Stable tag: 3.0.0
License: GPLv2 or later

Secure MecoPay WooCommerce gateway with automatic digital/physical product detection, physical advance/COD support, and HMAC-signed webhook synchronization.

== Installation ==
1. Upload the ZIP through WordPress Admin > Plugins > Add New > Upload Plugin.
2. Activate the plugin.
3. Go to WooCommerce > Settings > Payments > MecoPay.
4. Enter the Brand API Key from MecoPay Dashboard.
5. Enter the same Webhook Secret configured in MecoPay Dashboard.
6. Copy the displayed Webhook URL into MecoPay Dashboard > Webhook Settings.
7. Choose the physical advance amount; set it to 0 for full COD.

== Product type detection ==
- Virtual/downloadable products that do not need shipping are sent as digital.
- Shippable products use the configured advance amount for physical_advance, or physical_cod when it is 0.
- Digital and physical products cannot be mixed in one order.

== Security ==
Payment webhooks are accepted only with a valid X-MecoPay-Signature HMAC-SHA256 header. The plugin validates event status, order identity, amount, and duplicate delivery before updating an order.
